# Werkstatt ML – Website

Fertige statische Website für eine Kfz-Reparaturwerkstatt in Märkisch Linden bei Neuruppin.

## Vor dem Veröffentlichen ändern
In `index.html` bitte:
- Werkstattname
- Telefonnummer
- E-Mail-Adresse
- genaue Adresse
- Impressum
- Datenschutz
- Leistungen/Öffnungszeiten nach Bedarf

## Veröffentlichung mit GitHub Pages
1. Neues GitHub-Repository erstellen.
2. Alle Dateien dieses Ordners hochladen.
3. Repository → Settings → Pages.
4. Unter Build and deployment bei Source `GitHub Actions` auswählen.
5. Auf `main` pushen. GitHub Pages veröffentlicht die Seite anschließend automatisch.

GitHub Pages kann statische HTML/CSS/JavaScript-Seiten direkt aus einem Repository veröffentlichen.
