const toggle = document.querySelector('.menu-toggle');
const menu = document.querySelector('#navMenu');

toggle.addEventListener('click', () => menu.classList.toggle('open'));

document.querySelectorAll('#navMenu a').forEach(link => {
  link.addEventListener('click', () => menu.classList.remove('open'));
});

document.querySelector('#year').textContent = new Date().getFullYear();
